package com.example.desaparecidos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesaparecidosApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesaparecidosApplication.class, args);
	}

}
